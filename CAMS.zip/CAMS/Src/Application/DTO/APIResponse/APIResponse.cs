﻿namespace Application.DTO.APIResponse
{
    public class APIResponse
    {
        public int statusCode { get; set; }
        public object data { get; set; }
        public string message { get; set; }
        public int TotalPages { get; set; }
        public int TotalCount { get; set; }

    }
}
