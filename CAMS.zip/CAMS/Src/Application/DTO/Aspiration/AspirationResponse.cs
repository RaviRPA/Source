﻿using Application.DTO.Auditable;


namespace Application.DTO.Aspiration
{
    public class AspirationResponse : AuditableResponse
    {
        public string Title { get; set; }

        public string Description { get; set; }

        public string Type { get; set; }

        public string Status { get; set; }

        public bool? RMSApproved { get; set; }

        public bool? BUApproved { get; set; }

        public DateTime? FullFillBy { get; set; }

       
    }
}
