﻿using Application.DTO.Auditable;

namespace Application.DTO.Aspiration_Comments
{
    public class AspirationCommentsRequest : AuditableRequest
    {
        public  int AspirationId { get; set; }

        public string Comments { get; set; }
    }
}
