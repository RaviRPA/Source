﻿using Application.DTO.Auditable;

namespace Application.DTO.Aspiration_Comments
{
    public class AspirationCommentsResponse : AuditableResponse
    {
        public  int AspirationId { get; set; }
   
        public string Comments { get; set; }

        public string AspirationTitle { get; set; }
    }
}
