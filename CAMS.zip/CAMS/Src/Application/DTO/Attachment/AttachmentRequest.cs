﻿using Application.DTO.Auditable;


namespace Application.DTO.Attachment
{
    public class AttachmentRequest : AuditableRequest
    {
        public int AspirationId { get; set; }

        public string FilePath { get; set; }
    }
}
