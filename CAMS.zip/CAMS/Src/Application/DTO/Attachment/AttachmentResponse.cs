﻿using Application.DTO.Auditable;


namespace Application.DTO.Attachment
{
    public class AttachmentResponse : AuditableResponse
    {
        public int AspirationId { get; set; }

        public string FilePath { get; set; }

        public string AspirationTitle { get; set; }

    }
}
