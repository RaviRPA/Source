﻿namespace Application.DTO.Auditable
{
    public class AuditableRequest : IAuditableRequest
    {
        public int id { get; set; }
        public bool deleted { get; set; }
    }
}
