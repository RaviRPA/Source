﻿namespace Application.DTO.Auditable
{
    public interface IAuditableRequest
    {
        public int id { get; set; }
        public bool deleted { get; set; }
    }
}
