﻿namespace Application.DTO.Auditable
{
    public interface IAuditableResponse
    {
        public int id { get; set; }
        public Guid createdBy { get; set; }
        public Guid updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public DateTime createdDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
