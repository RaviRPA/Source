﻿using System.ComponentModel.DataAnnotations;

namespace Application.DTO.Authentication
{
    public class AuthenticateRequest
    {
        [Required]
        public string username { get; set; }
    }
}
