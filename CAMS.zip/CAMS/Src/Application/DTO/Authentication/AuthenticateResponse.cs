﻿namespace Application.DTO.Authentication
{
    public class AuthenticateResponse
    {
        public int id { get; set; }
        public string name { get; set; }
        public string mid { get; set; }
        public string email { get; set; }
        public string jwtToken { get; set; }
        public string refreshToken { get; set; }

        public AuthenticateResponse(int userId, string _jwtToken, string _refreshToken)
        {
            //id = user.Id;
            //name = user.Name_English;
            //name = user.Name_Korean;
            //mid = user.MID;
            //email = user.Email;
            //jwtToken = _jwtToken;
            //refreshToken = _refreshToken;
        }
    }
}
