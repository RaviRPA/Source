﻿namespace Application.DTO.Authentication
{
    public class JWTValidation
    {
        public int? userId { get; set; }
        public string errorMessage { get; set; }
    }
}
