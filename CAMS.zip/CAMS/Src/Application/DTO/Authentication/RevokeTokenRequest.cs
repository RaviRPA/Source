﻿namespace Application.DTO.Authentication
{
    public class RevokeTokenRequest
    {
        public string token { get; set; }
    }
}
