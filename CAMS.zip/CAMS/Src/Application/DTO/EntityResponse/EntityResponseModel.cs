﻿namespace Application.DTO.EntityResponse
{
    public class EntityResponseModel
    {
        public APIResponse.APIResponse APIResponse { get; set; }

        public object Entity { get; set; }
        public object EntityResponse { get; set; }


    }
}
