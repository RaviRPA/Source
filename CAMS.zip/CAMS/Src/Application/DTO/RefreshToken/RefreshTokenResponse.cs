﻿namespace Application.DTO.RefreshToken
{
    public class RefreshTokenResponse
    {
        public int id { get; set; }
        public string token { get; set; }
        public DateTime expires { get; set; }
        public DateTime created { get; set; }
        public DateTime? revoked { get; set; }
        public string revokedBy { get; set; }
        public string createdBy { get; set; }
        public string replacedByToken { get; set; }
        public string reasonRevoked { get; set; }
        public bool isExpired => DateTime.Now >= expires;
        public bool isRevoked => revoked != null;
        public bool isActive => !isRevoked && !isExpired;
        public int? employeeId { get; set; }

    }
}
