﻿using Application.DTO.Auditable;

namespace Application.DTO.WeatherForecast
{
    public class WeatherForecastRequest : AuditableRequest
    {
        public int temperatureC { get; set; }

        public int temperatureF { get; set; }

        public string? summary { get; set; }

        public string? name { get; set; }
    }
}
