﻿using Application.DTO.Auditable;

namespace Application.DTO.WeatherForecast
{
    public class WeatherForecastResponse : AuditableResponse
    {
        public int temperatureC { get; set; }

        public int temperatureF { get; set; }

        public string? summary { get; set; }
        public string? name { get; set; }
    }
}
