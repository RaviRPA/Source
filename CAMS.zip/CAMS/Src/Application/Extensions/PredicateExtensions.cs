﻿using Common;
using Common.Enums;
using System.Linq.Expressions;
using System.Reflection;

namespace Application.Extensions

{
    public static class PredicateExtensions
    {

        private static readonly MethodInfo OrderByMethod =
        typeof(Queryable).GetMethods().Single(method =>
        method.Name == "OrderBy" && method.GetParameters().Length == 2);

        private static readonly MethodInfo OrderByDescendingMethod =
            typeof(Queryable).GetMethods().Single(method =>
            method.Name == "OrderByDescending" && method.GetParameters().Length == 2);
        class ParameterReplaceVisitor : ExpressionVisitor
        {
            private readonly ParameterExpression from, to;
            public ParameterReplaceVisitor(ParameterExpression from, ParameterExpression to)
            {
                this.from = from;
                this.to = to;
            }
            protected override Expression VisitParameter(ParameterExpression node)
            {
                return node == from ? to : base.VisitParameter(node);
            }


        }

        /// 	<summary>

        /// Begin an expression chain

        /// 	</summary>

        /// 	<typeparam name="T"></typeparam>

        /// 	<param name="value">Default return value if the chanin is ended early</param>

        /// 	<returns>A lambda expression stub</returns>

        public static Expression<Func<T, bool>> Begin<T>(bool value = false)
        {
            if (value)
                return parameter => true; 	//value cannot be used in place of true/false
            return parameter => false;
        }

        public static Expression<Func<T, bool>> And<T>(this Expression<Func<T, bool>> left, Expression<Func<T, bool>> right)
        {
            return left.CombineLambdas(right, ExpressionType.AndAlso);
        }

        public static Expression<Func<T, bool>> Or<T>(this Expression<Func<T, bool>> left, Expression<Func<T, bool>> right)
        {
            return left.CombineLambdas(right, ExpressionType.OrElse);
        }
        public static T MapData<T>(T src, T des)
        {
            PropertyInfo[] propertyinfos = des.GetType().GetProperties();
            PropertyInfo[] propertyinfo = src.GetType().GetProperties();
            foreach (PropertyInfo item1 in propertyinfos)
            {
                foreach (PropertyInfo item in propertyinfo)
                {
                    if (item1.Name == item.Name)
                    {
                        var objSrc = item.GetValue(src);
                        var objDes = item1.GetValue(des);
                        if (objSrc != null && objSrc != objDes)
                        {
                            item1.SetValue(des, objSrc);
                        }
                    }
                }

            }
            return des;
        }

        public static Expression<Func<T, bool>> GetExpressionFromProperties<T>(this Expression<Func<T, bool>> expression, T obj, FilterCondition filterCondition)
        {
            int count = 0;
            if (filterCondition.FilterModels.Count > 1)
                expression = expression.GetExpressionFromProperties(obj, filterCondition.FilterModels[0]);
            foreach (var item in filterCondition.FilterModels)
            {
                Expression<Func<T, bool>> expression1 = GetExpressionFromProperties(null, obj, item);
                if (filterCondition.Combination[count] == FilterCombination.And)
                    expression = expression.And(expression1);
                else
                    expression = expression.Or(expression1);
            }
            return expression;
        }
        public static Expression<Func<T, bool>> GetExpressionFromProperties<T>(this Expression<Func<T, bool>> left, T obj, FilterModel[] filterModels)
        {
            Expression<Func<T, bool>> e2 = null;
            var properties = obj.GetType().GetProperties();//jobTitleRequest here is nothing but an new instance of jobtitleRequest 
            int index = 0;
            List<Expression<Func<T, bool>>> expressions = new List<Expression<Func<T, bool>>>();

            foreach (var item in filterModels)
            {
                foreach (var prop in properties)
                {
                    if (prop.Name.ToLower() == item.Key.ToLower())
                    {
                        ParameterExpression argParam = Expression.Parameter(obj.GetType(), "v");
                        var value = Expression.Constant("Modules");
                        Expression nameProperty = Expression.Property(argParam, prop.Name);
                        if (item.Value != "string" && !string.IsNullOrEmpty(item.Value))
                        {
                            if (nameProperty.Type == typeof(string))
                            {
                                value = Expression.Constant(Convert.ToString(item.Value));

                            }

                            else if (nameProperty.Type == typeof(int))
                            {

                                value = Expression.Constant(Convert.ToInt32(item.Value));

                            }
                            else if (nameProperty.Type == typeof(int?))
                            {
                                int? val = int.TryParse(item.Value, out var tempVal) ? tempVal : null;
                                value = Expression.Constant(val, typeof(int?));

                            }

                            else if (nameProperty.Type == typeof(bool))
                            {

                                value = Expression.Constant(Convert.ToBoolean(item.Value));

                            }
                            else if (nameProperty.Type == typeof(decimal))
                            {
                                value = Expression.Constant(Convert.ToDecimal(item.Value));

                            }
                            else if (nameProperty.Type == typeof(double))
                            {

                                value = Expression.Constant(Convert.ToDouble(item.Value));

                            }
                            else if (nameProperty.Type == typeof(double?))
                            {
                                double? val = double.TryParse(item.Value, out var tempVal) ? tempVal : null;
                                value = Expression.Constant(val, typeof(double?));
                            }

                            else if (nameProperty.Type == typeof(DateTime))
                            {
                                value = Expression.Constant(Convert.ToDateTime(item.Value));

                            }
                            else if (nameProperty.Type == typeof(DateTime?))
                            {
                                DateTime? val = DateTime.TryParse(item.Value, out var tempVal) ? tempVal : null;

                                value = Expression.Constant(val, typeof(DateTime?));

                            }
                            else if (nameProperty.Type.ToString().ToLower().Contains("enum"))
                            {
                                value = Expression.Constant(Enum.Parse(nameProperty.Type, item.Value));
                                //value = Expression.Constant(Convert.ToInt32(item.Value));

                            }

                            Expression e1 = AddOperatorToExpression(nameProperty, value, (FilterType)Enum.Parse(typeof(FilterType), item.Type));
                            //Expression e1 = Expression.Equal(nameProperty, value);

                            e2 = Expression.Lambda<Func<T, bool>>(e1, argParam);
                            if (left == null)
                            {
                                left = e2;
                            }
                            if (item.Combination == FilterCombination.And)
                                left = left.And(e2);
                            else
                                left = left.Or(e2);
                        }

                    }
                }
                index++;
            }
            //  e2 = Combine<T, bool>(expressions.ToArray());

            return left;
        }

        public static IQueryable<T> GetSortOrder<T>(this IQueryable<T> source, string sortProperty, int sortOrder)
        {
            T instance = (T)Activator.CreateInstance(typeof(T));
            var properties = instance.GetType().GetProperties();
            sortProperty = properties.Where(x => x.Name.ToLower() == sortProperty.ToLower()).FirstOrDefault().Name;
            if (sortOrder == 1)
            {
                source = source.OrderByProperty(sortProperty);
            }
            else
            {
                source = source.OrderByPropertyDescending(sortProperty);

            }
            return source;
        }
        public static IQueryable<T> OrderByPropertyDescending<T>(
       this IQueryable<T> source, string propertyName)
        {
            if (typeof(T).GetProperty(propertyName, BindingFlags.IgnoreCase |
                BindingFlags.Public | BindingFlags.Instance) == null)
            {
                return null;
            }
            ParameterExpression paramterExpression = Expression.Parameter(typeof(T));
            Expression orderByProperty = Expression.Property(paramterExpression, propertyName);
            LambdaExpression lambda = Expression.Lambda(orderByProperty, paramterExpression);
            MethodInfo genericMethod = OrderByDescendingMethod.MakeGenericMethod(typeof(T), orderByProperty.Type);
            object ret = genericMethod.Invoke(null, new object[] { source, lambda });
            return (IQueryable<T>)ret;
        }
        public static IQueryable<T> OrderByProperty<T>(
      this IQueryable<T> source, string propertyName)
        {
            if (typeof(T).GetProperty(propertyName, BindingFlags.IgnoreCase |
                BindingFlags.Public | BindingFlags.Instance) == null)
            {
                return null;
            }
            ParameterExpression paramterExpression = Expression.Parameter(typeof(T));
            Expression orderByProperty = Expression.Property(paramterExpression, propertyName);
            LambdaExpression lambda = Expression.Lambda(orderByProperty, paramterExpression);
            MethodInfo genericMethod =
              OrderByMethod.MakeGenericMethod(typeof(T), orderByProperty.Type);
            object ret = genericMethod.Invoke(null, new object[] { source, lambda });
            return (IQueryable<T>)ret;
        }

        #region private

        private static Expression AddOperatorToExpression(Expression property, ConstantExpression value, FilterType operatorVal)
        {
            Expression expression = null;
            switch (operatorVal)
            {
                case FilterType.e:
                    expression = Expression.Equal(property, value);
                    break;
                case FilterType.ne:
                    expression = Expression.NotEqual(property, value);
                    break;
                case FilterType.lt:
                    expression = Expression.LessThan(property, value);
                    break;
                case FilterType.gt:
                    expression = Expression.GreaterThan(property, value);
                    break;
                case FilterType.le:
                    expression = Expression.LessThanOrEqual(property, value);
                    break;
                case FilterType.ge:
                    expression = Expression.GreaterThanOrEqual(property, value);
                    break;
                case FilterType.c:
                    var containsmethod = value.Type.GetMethod("Contains", new[] { typeof(string) });
                    expression = Expression.Call(property, containsmethod, value);
                    break;
                case FilterType.sw:
                    var startsWithMethod = value.Type.GetMethod("StartsWith", new[] { typeof(string) });
                    expression = Expression.Call(property, startsWithMethod, value);
                    break;
                case FilterType.ew:
                    var endsWithMethod = value.Type.GetMethod("EndsWith", new[] { typeof(string) });
                    expression = Expression.Call(property, endsWithMethod, value);
                    break;
            }
            return expression;
        }
        private static Expression<Func<T, bool>> CombineLambdas<T>(this Expression<Func<T, bool>> left, Expression<Func<T, bool>> right, ExpressionType expressionType)
        {
            //Remove expressions created with Begin<T>()

            if (IsExpressionBodyConstant(left))
                return right;

            ParameterExpression p = left.Parameters[0];
            SubstituteParameterVisitor visitor = new SubstituteParameterVisitor();
            visitor.Sub[right.Parameters[0]] = p;
            Expression body = Expression.MakeBinary(expressionType, left.Body, visitor.Visit(right.Body));
            return Expression.Lambda<Func<T, bool>>(body, p);
        }
        public static LambdaExpression PropertyGetLambda(Type parameterType, string propertyName, Type propertyType)
        {
            var parameter = Expression.Parameter(parameterType);
            var memberExpression = Expression.Property(parameter, propertyName);
            var lambdaExpression = Expression.Lambda(memberExpression, parameter);
            return lambdaExpression;
        }


        private static bool IsExpressionBodyConstant<T>(Expression<Func<T, bool>> left)
        {
            return left.Body.NodeType == ExpressionType.Constant;
        }

        internal class SubstituteParameterVisitor : ExpressionVisitor
        {
            public Dictionary<Expression, Expression> Sub = new Dictionary<Expression, Expression>();
            protected override Expression VisitParameter(ParameterExpression node)
            {

                Expression newValue;

                if (Sub.TryGetValue(node, out newValue))
                {
                    return newValue;
                }
                return node;
            }

        }

        #endregion
    }
}
