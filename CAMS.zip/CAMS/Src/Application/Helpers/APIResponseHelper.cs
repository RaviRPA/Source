﻿using Application.DTO.APIResponse;

namespace Application.Helpers
{
    public class APIResponseHelper
    {
        private static APIResponseHelper _apiResponseHelper;

        public static APIResponseHelper Getinstance()
        {
            if (_apiResponseHelper == null)
            {
                _apiResponseHelper = new APIResponseHelper();
            }
            return _apiResponseHelper;
        }
        public APIResponse ConvertToAPIResponse(object response,
                                                string message = null, int TotalPages = 0, int totalCount = 0)
        {
            return new APIResponse
            {
                data = response,
                message = message != "Success" ? message : "Success",
                TotalPages = TotalPages,
                TotalCount = totalCount,
                statusCode = message != "Success" ? 200 : 404
            };
        }

    }
}
