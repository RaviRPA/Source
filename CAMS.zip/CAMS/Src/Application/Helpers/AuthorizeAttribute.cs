﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Filters;
//using Microsoft.AspNetCore.Routing;
//using System;
//using System.Collections.Generic;

//namespace League_10.DeviceRegistration.Application.Helpers
//{
//    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
//    public class AuthorizeAttribute : Attribute, IAuthorizationFilter
//    {
//        public void OnAuthorization(AuthorizationFilterContext context)
//        {
//            if (context.HttpContext.Items["UserId"] == null)
//            {
//                var allowed = false;
//                var skipPaths = new List<string>() { "download", "getCodesByGroup", "getRolesWithUsers" };
//                foreach (string path in skipPaths)
//                {
//                    if (context.HttpContext.Request.Path.ToString().ToLower().Contains(path.ToLower()))
//                    {
//                        allowed = true;
//                    }
//                }
//                if (!allowed)
//                {
//                    context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
//                    //context.Result = new UnauthorizedResult();
//                    return;
//                }
//                // context.Result = new RedirectToRouteResult
//                //(
//                //new RouteValueDictionary(new
//                //{
//                //    action = "Error",
//                //    controller = "Error"
//                //}));
//            }
//            else if (context.HttpContext.Items["UserId"] != null)
//            {
//                var account = (int)context.HttpContext.Items["UserId"];
//                if (account == 0)
//                {
//                    // not logged in
//                    //context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
//                    context.Result = new UnauthorizedResult();
//                    return;
//                }
//            }
//        }
//    }
//}
