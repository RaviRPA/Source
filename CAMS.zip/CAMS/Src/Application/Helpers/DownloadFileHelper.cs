﻿//using League_10.DeviceRegistration.Application.Helpers.Interfaces;
//using Microsoft.AspNetCore.Mvc;

//namespace League_10.DeviceRegistration.Application.Helpers
//{
//    public class DownloadFileHelper : IDownloadFile
//    {
//        public async Task<Microsoft.AspNetCore.Mvc.FileStreamResult> DownlodfileAsync(int id, string path)
//        {
//            string filename = string.Empty;
//            string filePath = string.Empty;
//            filePath = path;
//            string fullpath = Path.Combine(filePath, filename);
//            filename = Path.GetFileName(filePath);
//            var mimeType = "application/octet-stream";
//            var stream = File.OpenRead(filePath);
//            return new FileStreamResult(stream, mimeType) { FileDownloadName = filename };
//        }

//    }
//}
