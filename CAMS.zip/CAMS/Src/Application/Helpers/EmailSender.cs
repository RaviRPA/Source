﻿using Application.Helpers.Interfaces;
using Microsoft.Extensions.Options;
using System.Net.Mail;

namespace Application.Helpers
{
    public class EmailSender : IEmailer
    {
        private SmtpConfig _config;

        public EmailSender(IOptions<SmtpConfig> config)
        {
            _config = config.Value;
        }

        public (bool success, string errorMsg) SendEmailAsync(string recepientName, string recepientEmail, List<KeyValuePair<string, string>> ccEmails,
          string subject, string body, SmtpConfig config = null)
        {
            MailMessage messageObject = new MailMessage();
            MailAddress Address;
            MailAddressCollection TO_addressList = new MailAddressCollection();
            MailAddressCollection addressList = new MailAddressCollection();

            string senderName = _config.Name;
            string senderEmail = _config.EmailAddress;

            messageObject.Subject = subject;
            messageObject.Body = body;
            messageObject.IsBodyHtml = true;
            messageObject.From = new MailAddress(senderEmail);

            ccEmails = ccEmails.Distinct().ToList();
            var recepientNamelst = recepientName.Split(';').Distinct().ToArray();
            recepientName = string.Join(';', recepientNamelst);
            var recepientEmaillst = recepientEmail.Split(';').Distinct().ToArray();
            recepientEmail = string.Join(';', recepientEmaillst);
            if (ccEmails != null && ccEmails.Count > 0)
            {
                foreach (var ccEmail in ccEmails)
                {
                    Address = new MailAddress(ccEmail.Value);
                    addressList.Add(Address);
                }
                messageObject.CC.Add(addressList.ToString());
            }

            recepientEmail = !string.IsNullOrEmpty(recepientEmail) && recepientEmail.Trim().EndsWith(';') ? recepientEmail.Trim().Substring(0, recepientEmail.Trim().Length - 1) : recepientEmail.Trim();
            addressList.Clear();
            if (!string.IsNullOrEmpty(recepientEmail))
            {
                foreach (var ccEmail in recepientEmail.Split(';'))
                {
                    Address = new MailAddress(ccEmail);
                    addressList.Add(Address);
                }
                messageObject.To.Add(addressList.ToString());
            }

            SmtpClient client = new SmtpClient();
            client.Host = _config.Host;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Port = _config.Port;
            client.UseDefaultCredentials = true;
            client.EnableSsl = false;
            client.Send(messageObject);

            return (true, null);
        }



    }

    public class SmtpConfig
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public bool UseSSL { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
