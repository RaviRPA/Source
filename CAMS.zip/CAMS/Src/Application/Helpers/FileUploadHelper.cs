﻿using Application.Helpers.Interfaces;
using Microsoft.AspNetCore.Http;

namespace Application.Helpers
{
    public class FileUploadHelper : IFileUpload
    {
        public async void UplaodFileAsync(IFormFile file, string path)
        {
            var fileName = string.Empty;
            if (file != null)
            {
                var extension = Path.GetExtension(file?.FileName).ToLower();
                fileName = Path.GetFileNameWithoutExtension(file?.FileName);
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                DateTime now = DateTime.Now;
                var filename = fileName + extension;
                var fullPath = Path.Combine(path, filename);
                using (var fileStream = new FileStream(fullPath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
            }
        }
    }
}
