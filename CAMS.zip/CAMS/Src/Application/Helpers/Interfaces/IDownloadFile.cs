﻿namespace Application.Helpers.Interfaces
{
    public interface IDownloadFile
    {
        //Task<Microsoft.AspNetCore> DownlodfileAsync(int id, string path);
    }
}
