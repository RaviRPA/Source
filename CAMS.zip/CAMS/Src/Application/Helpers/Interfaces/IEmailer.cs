﻿namespace Application.Helpers.Interfaces
{
    public interface IEmailer
    {
        (bool success, string errorMsg) SendEmailAsync(string recepientName, string recepientEmail, List<KeyValuePair<string, string>> ccEmails, string subject, string body, SmtpConfig config = null);
    }
}
