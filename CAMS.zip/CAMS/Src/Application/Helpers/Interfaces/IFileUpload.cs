﻿using Microsoft.AspNetCore.Http;

namespace Application.Helpers.Interfaces
{
    public interface IFileUpload
    {
        void UplaodFileAsync(IFormFile file, string path);
    }
}
