﻿using Application.DTO.Authentication;
using Core.Entities;

namespace Application.Helpers.Interfaces
{
    public interface IJwtUtils
    {
        public string GenerateJwtToken(int userId);
        public JWTValidation ValidateJwtToken(string token);
        public RefreshToken GenerateRefreshToken(int userId);
        JWTValidation ValidateRefreshToken(string token);
    }
}
