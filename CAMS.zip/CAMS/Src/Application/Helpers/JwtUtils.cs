﻿//using League_10.DeviceRegistration.Application.DTO.Authentication;
//using League_10.DeviceRegistration.Application.Helpers.Interfaces;
//using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.Tokens;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Security.Cryptography;
//using System.Text;
//using League_10.DeviceRegistration.Core.Entities;
//using League_10.DeviceRegistration.Infrastructure.Context;

//namespace League_10.DeviceRegistration.Application.Helpers
//{
//    public class JwtUtils : IJwtUtils
//    {
//        private readonly IConfiguration _config;
//        private readonly DataContext _context;
//        public JwtUtils(IConfiguration config, DataContext context)
//        {
//            _config = config;
//            _context = context;
//        }

//        public string GenerateJwtToken(Employee user)
//        {
//            // generate token that is valid for 15 minutes
//            var tokenHandler = new JwtSecurityTokenHandler();
//            var key = Encoding.ASCII.GetBytes(_config["JWT:Secret"]);
//            var tokenDescriptor = new SecurityTokenDescriptor
//            {
//                Subject = new ClaimsIdentity(new[] { new Claim("id", user.Id.ToString()) }),
//                Expires = DateTime.Now.AddMinutes(Convert.ToInt32(_config["JWT:JWTLifeTime"])),
//                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
//            };
//            var token = tokenHandler.CreateToken(tokenDescriptor);
//            return tokenHandler.WriteToken(token);
//        }

//        public JWTValidation ValidateJwtToken(string token)
//        {
//            JWTValidation response = new JWTValidation();
//            if (token == null)
//            {
//                response.userId = null;
//                response.errorMessage = "Token not found";
//                return response;
//            }

//            var tokenHandler = new JwtSecurityTokenHandler();
//            var key = Encoding.ASCII.GetBytes(_config["JWT:Secret"]);
//            try
//            {
//                tokenHandler.ValidateToken(token, new TokenValidationParameters
//                {
//                    ValidateIssuerSigningKey = true,
//                    IssuerSigningKey = new SymmetricSecurityKey(key),
//                    ValidateIssuer = false,
//                    ValidateAudience = false,
//                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
//                    ClockSkew = TimeSpan.Zero
//                }, out SecurityToken validatedToken);

//                var jwtToken = (JwtSecurityToken)validatedToken;
//                var userId = int.Parse(jwtToken.Claims.First(x => x.Type == "id").Value);

//                // return user id from JWT token if validation successful
//                response.userId = userId;
//                response.errorMessage = string.Empty;
//                return response;
//            }
//            catch (Exception ex)
//            {
//                response.userId = null;
//                response.errorMessage = ex.Message.Contains("Signature validation failed") ?
//                    "Invalid Access Token" : ex.Message.Contains("Lifetime validation failed") ?
//                    "Access Token Expired" : "Unknown issue with JWT";
//                return response;
//            }
//        }

//        public JWTValidation ValidateRefreshToken(string token)
//        {
//            JWTValidation result = new JWTValidation();
//            var refreshTokenDetails = _context.RefreshTokens.SingleOrDefault(x => x.Token.Trim() == token);
//            if (refreshTokenDetails == null)
//            {
//                result.errorMessage = "Invalid Refresh Token";
//            }
//            else if (refreshTokenDetails.IsExpired)
//            {
//                result.errorMessage = "Refresh Token Expired";
//            }
//            return result;
//        }
//        public RefreshToken GenerateRefreshToken(int userId)
//        {
//            var refreshToken = new RefreshToken
//            {
//                Token = getUniqueToken(),
//                ReasonRevoked = string.Empty,
//                Revoked = DateTime.Now,
//                RevokedBy = string.Empty,
//                ReplacedByToken = string.Empty,
//                // token is valid for 7 days
//                Expires = DateTime.Now.AddDays(Convert.ToInt32(_config["JWT:RefreshTokenLifeTime"])),
//                CreatedDate = DateTime.Now,
//                CreatedBy = userId,
//            };

//            return refreshToken;

//            string getUniqueToken()
//            {
//                // token is a cryptographically strong random sequence of values
//                var token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
//                // ensure token is unique by checking against db
//                var tokenIsUnique = !_context.Employees.Any(u => u.RefreshTokens.Any(t => t.Token == token));
//                if (!tokenIsUnique)
//                    return getUniqueToken();

//                return token;
//            }
//        }

//        RefreshToken IJwtUtils.GenerateRefreshToken(int userId)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
