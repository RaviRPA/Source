﻿namespace Application.Helpers
{
    //public class Resolver :IValueResolver<DateTime, DateTime, string>
    //{

    //        private readonly string _myAppUrl;


    //        public Resolver(IConfiguration configuration)
    //        {
    //            _myAppUrl = configuration["MyAppUrl"];
    //        }
    //        protected override string Resolve(DateTime sdt, DateTime tdt, string s, ResolutionContext context)
    //        {
    //            return tdt.ToShortDateString();
    //        }

    //}
}
