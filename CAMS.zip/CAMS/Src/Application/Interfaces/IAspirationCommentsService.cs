﻿namespace Application.Interfaces
{
    public interface IAspirationCommentsService : IService
    {
    }
}
