﻿namespace Application.Interfaces
{
    public interface IAspirationService : IService
    {
    }
}
