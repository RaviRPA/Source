﻿namespace Application.Interfaces
{
    public interface IAttachmentService : IService
    {
    }
}