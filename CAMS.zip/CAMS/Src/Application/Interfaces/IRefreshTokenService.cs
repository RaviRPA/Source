﻿namespace Application.Interfaces
{
    public interface IRefreshTokenService : IService
    {

    }
}
