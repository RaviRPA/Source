﻿using Application.DTO.Auditable;
using Application.DTO.EntityResponse;
using Common;

namespace Application.Interfaces
{
    public interface IService
    {
        Task<EntityResponseModel> UpdateAsync(List<IAuditableRequest> models);
        Task<EntityResponseModel> CreateAsync(List<IAuditableRequest> models);
        Task<EntityResponseModel> GetAsync(FilterCondition filterCondition);
        //Task<EntityResponseModel> CountAsync(FilterCondition filterCondition);
        Task<bool> DeleteAsync(List<int> ids);
    }
}
