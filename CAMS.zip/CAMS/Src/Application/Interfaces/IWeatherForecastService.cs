﻿namespace Application.Interfaces
{
    public interface IWeatherForecastService : IService
    {

    }
}
