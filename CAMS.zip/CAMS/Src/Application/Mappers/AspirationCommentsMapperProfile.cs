﻿using Application.DTO.Aspiration_Comments;
using AutoMapper;
using Core.Entities;

namespace Application.Mappers
{
    public class AspirationCommentsMapperProfile : Profile
    {
        public AspirationCommentsMapperProfile()
        {
            CreateMap<AspirationCommentsRequest, Aspiration_Comments>().ReverseMap();
            CreateMap<AspirationCommentsResponse, Aspiration_Comments>().ReverseMap();
        }
    }
}
