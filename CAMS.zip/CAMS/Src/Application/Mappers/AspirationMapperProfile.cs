﻿using Application.DTO.Aspiration;
using AutoMapper;
using Core.Entities;

namespace Application.Mappers
{
    public class AspirationMapperProfile : Profile
    {
        public AspirationMapperProfile() 
        {
            CreateMap<AspirationRequest, Aspiration>().ReverseMap();
            CreateMap<AspirationResponse, Aspiration>().ReverseMap();
        }
    }
}
