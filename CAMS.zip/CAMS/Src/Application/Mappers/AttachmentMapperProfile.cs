﻿using Application.DTO.Attachment;
using AutoMapper;
using Core.Entities;

namespace Application.Mappers
{
    public class AttachmentMapperProfile : Profile
    {
        public AttachmentMapperProfile()
        {
            CreateMap<AttachmentRequest, Attachment>().ReverseMap();
            CreateMap<AttachmentResponse, Attachment>().ReverseMap();
        }
    }
}
