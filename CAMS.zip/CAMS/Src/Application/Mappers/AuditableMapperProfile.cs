﻿using Application.DTO.Auditable;
using AutoMapper;
using Core.Entities.BaseEntity;

namespace Application.Mappers
{
    public class AuditableMapperProfile : Profile
    {
        public AuditableMapperProfile()
        {
            CreateMap<AuditableEntity, AuditableRequest>().ReverseMap();
            CreateMap<AuditableEntity, AuditableResponse>().ReverseMap();
        }
    }
}
