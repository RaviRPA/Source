﻿using Application.DTO.WeatherForecast;
using AutoMapper;
using Core.Entities;

namespace Application.Mappers
{
    public class WeatherForecastMapperProfile : Profile
    {
        public WeatherForecastMapperProfile()
        {
            CreateMap<WeatherForecastRequest, WeatherForecast>().ReverseMap();
            CreateMap<WeatherForecastResponse, WeatherForecast>().ReverseMap();
        }
    }
}
