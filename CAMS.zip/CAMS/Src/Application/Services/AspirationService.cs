﻿using Application.DTO.Auditable;
using Application.DTO.EntityResponse;
using Application.DTO.Aspiration;
using Application.Extensions;
using Application.Helpers;
using Application.Interfaces;
using AutoMapper;
using Common;
using Common.Enums;
using Core.Entities;
using Core.Entities.BaseEntity;
using Infrastructure.Repository.Interfaces;
using Infrastructure.Specifications.Interfaces;
using System.Data;
using System.Linq.Expressions;

namespace Application.Services
{
    public class AspirationService : IAspirationService
    {
        //private readonly IUnitOfWork<DataContext> _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IRepository<Aspiration> _repository;
        int pageNo = 1;
        int pageSize = 10;
        public AspirationService(IMapper mapper
            , IRepository<Aspiration> repository)
        {
            //_unitOfWork = unitOfWork;
            _mapper = mapper;
            _repository = repository;
        }

        private ISpecification<Aspiration> GetSpecification(Expression<Func<Aspiration, bool>> expression = null, string sortField = "none", int sortOrder = -1)
        {

            if (expression == null)
                expression = v => v.IsDeleted != true;
            Infrastructure.Specifications.BaseSpecification<Aspiration> specification =
                                                                new Infrastructure.Specifications.BaseSpecification<Aspiration>(expression);

            if (sortField != "none" && !string.IsNullOrEmpty(sortField))
                specification.OrderByDescending = p => p.GetSortOrder(sortField, sortOrder);
            else
                specification.OrderByDescending = p => p.OrderByDescending(p => p.IsActive)
                                                   .ThenByDescending(p => p.CreatedDate)
                                                   .ThenByDescending(p => p.Id);
            specification.IsPagingEnabled = true;
            specification.Skip = (pageNo - 1) * pageSize;
            specification.Take = pageSize;

            return specification;
        }


        public async Task<EntityResponseModel> UpdateAsync(List<IAuditableRequest> models)
        {
            List<Aspiration> entities = new List<Aspiration>();
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            foreach (var item in models)
            {
                if (item == null) continue;
                AspirationRequest aspirationRequest = (AspirationRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "Id",
                            Type = FilterType.e.ToString(),
                            Value = aspirationRequest.id.ToString()
                        }
                   };
                Expression<Func<Aspiration, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Aspiration(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) == 1)
                {
                    var entity = _mapper.Map<Aspiration>(aspirationRequest);
                    await _repository.UpdateAsync(entity);
                    //await _unitOfWork.SaveAsync();

                    entities.Add(entity);
                }

            }
            entityResponseModel.Entity = entities;
            entityResponseModel.EntityResponse = _mapper.Map<List<AspirationResponse>>(entities);
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }

        public async Task<EntityResponseModel> CreateAsync(List<IAuditableRequest> models)
        {
            EntityResponseModel entityResponses = new EntityResponseModel();
            List<Aspiration> entities = new List<Aspiration>();
            //models = null;
            foreach (var item in models)
            {
                if (item == null) continue;
                AspirationRequest aspirationRequest = (AspirationRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "Title",
                            Type = FilterType.e.ToString(),
                            Value = aspirationRequest.Title
                        }
                   };
                Expression<Func<Aspiration, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Aspiration(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) < 1)
                {
                    var entity = _mapper.Map<Aspiration>(aspirationRequest);
                    await _repository.AddAsync(entity);
                    entities.Add(entity);
                }

            }
            entityResponses.EntityResponse = _mapper.Map<List<AspirationResponse>>(entities);
            entityResponses.Entity = entities;
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponses.EntityResponse, string.Empty),
                Entity = entityResponses.Entity,
                EntityResponse = entityResponses.EntityResponse
            };
        }

        public async Task<bool> DeleteAsync(List<int> ids)
        {
            List<AuditableEntity> entities = new List<AuditableEntity>();

            foreach (var item in ids)
            {
                if (item == null) continue;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "id",
                            Type = FilterType.e.ToString(),
                            Value = item.ToString()
                        }
                   };
                Expression<Func<Aspiration, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Aspiration(), filterConditions);
                var entity = await _repository.FindAsync(GetSpecification(expression));
                var entityVal = entity.FirstOrDefault();
                if (entityVal != null)
                {
                    await _repository.RemoveAsync(entityVal);
                }
            }
            return true;

        }

        public async Task<EntityResponseModel> GetAsync(FilterCondition filterCondition)
        {
            Expression<Func<Aspiration, bool>> expression = v => v.IsDeleted != true;
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            if (filterCondition != null && filterCondition.FilterModels.Any())
                expression = expression.GetExpressionFromProperties(new Aspiration(), filterCondition);
            var entities = await _repository.FindAsync(GetSpecification(expression));
            entityResponseModel.EntityResponse = _mapper.Map<List<AspirationResponse>>(entities);

            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }
    }
}
