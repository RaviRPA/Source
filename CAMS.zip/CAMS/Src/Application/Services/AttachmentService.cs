﻿using Application.DTO.Auditable;
using Application.DTO.EntityResponse;
using Application.DTO.Attachment;
using Application.Extensions;
using Application.Helpers;
using Application.Interfaces;
using AutoMapper;
using Common;
using Common.Enums;
using Core.Entities;
using Core.Entities.BaseEntity;
using Infrastructure.Repository.Interfaces;
using Infrastructure.Specifications.Interfaces;
using System.Data;
using System.Linq.Expressions;

namespace Application.Services
{
    public class AttachmentService : IAttachmentService
    {
        //private readonly IUnitOfWork<DataContext> _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IRepository<Attachment> _repository;
        int pageNo = 1;
        int pageSize = 10;
        public AttachmentService(IMapper mapper
            , IRepository<Attachment> repository)
        {
            //_unitOfWork = unitOfWork;
            _mapper = mapper;
            _repository = repository;
        }

        private ISpecification<Attachment> GetSpecification(Expression<Func<Attachment, bool>> expression = null, string sortField = "none", int sortOrder = -1)
        {

            if (expression == null)
                expression = v => v.IsDeleted != true;
            Infrastructure.Specifications.BaseSpecification<Attachment> specification =
                                                                new Infrastructure.Specifications.BaseSpecification<Attachment>(expression);

            if (sortField != "none" && !string.IsNullOrEmpty(sortField))
                specification.OrderByDescending = p => p.GetSortOrder(sortField, sortOrder);
            else
                specification.OrderByDescending = p => p.OrderByDescending(p => p.IsActive)
                                                   .ThenByDescending(p => p.CreatedDate)
                                                   .ThenByDescending(p => p.Id);
            specification.IsPagingEnabled = true;
            specification.Skip = (pageNo - 1) * pageSize;
            specification.Take = pageSize;

            return specification;
        }


        public async Task<EntityResponseModel> UpdateAsync(List<IAuditableRequest> models)
        {
            List<Attachment> entities = new List<Attachment>();
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            foreach (var item in models)
            {
                if (item == null) continue;
                AttachmentRequest attachmentRequest = (AttachmentRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "Id",
                            Type = FilterType.e.ToString(),
                            Value = attachmentRequest.id.ToString(),
                        }
                   };
                Expression<Func<Attachment, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Attachment(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) == 1)
                {
                    var entity = _mapper.Map<Attachment>(attachmentRequest);
                    await _repository.UpdateAsync(entity);
                    //await _unitOfWork.SaveAsync();

                    entities.Add(entity);
                }

            }
            entityResponseModel.Entity = entities;
            entityResponseModel.EntityResponse = _mapper.Map<List<AttachmentResponse>>(entities);
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }

        public async Task<EntityResponseModel> CreateAsync(List<IAuditableRequest> models)
        {
            EntityResponseModel entityResponses = new EntityResponseModel();
            List<Attachment> entities = new List<Attachment>();

            foreach (var item in models)
            {
                if (item == null) continue;
                AttachmentRequest attachmentRequest = (AttachmentRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "Id",
                            Type = FilterType.e.ToString(),
                            Value = attachmentRequest.id.ToString(),
                        }
                   };
                Expression<Func<Attachment, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Attachment(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) < 1)
                {
                    var entity = _mapper.Map<Attachment>(attachmentRequest);
                    await _repository.AddAsync(entity);
                    entities.Add(entity);
                }

            }
            entityResponses.EntityResponse = _mapper.Map<List<AttachmentResponse>>(entities);
            entityResponses.Entity = entities;
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponses.EntityResponse, string.Empty),
                Entity = entityResponses.Entity,
                EntityResponse = entityResponses.EntityResponse
            };
        }

        public async Task<bool> DeleteAsync(List<int> ids)
        {
            List<AuditableEntity> entities = new List<AuditableEntity>();

            foreach (var item in ids)
            {
                if (item == null) continue;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "id",
                            Type = FilterType.e.ToString(),
                            Value = item.ToString()
                        }
                   };
                Expression<Func<Attachment, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new Attachment(), filterConditions);
                var entity = await _repository.FindAsync(GetSpecification(expression));
                var entityVal = entity.FirstOrDefault();
                if (entityVal != null)
                {
                    await _repository.RemoveAsync(entityVal);
                }
            }
            return true;

        }

        public async Task<EntityResponseModel> GetAsync(FilterCondition filterCondition)
        {
            Expression<Func<Attachment, bool>> expression = v => v.IsDeleted != true;
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            if (filterCondition != null && filterCondition.FilterModels.Any())
                expression = expression.GetExpressionFromProperties(new Attachment(), filterCondition);
            var entities = await _repository.FindAsync(new string[] { "Aspiration" }, GetSpecification(expression));
            entityResponseModel.EntityResponse = _mapper.Map<List<AttachmentResponse>>(entities);

            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }
    }
}
