﻿using Application.Interfaces;
using Common;
using Core.Entities;
using Infrastructure.Repository.Interfaces;
using System.Reflection.Metadata.Ecma335;

namespace Application.Services
{
    public class DashBoardService : IDashBoardService
    {
        private readonly IRepository<Aspiration> _repository;
        public DashBoardService(IRepository<Aspiration> repository) 
        {
            _repository = repository;
        }

        async Task<object> IDashBoardService.GetTypeWiseAspirationAsync(FilterCondition filterCondition)
        {
            var entities = await _repository.FindAllAsync();
            var aspirationTypes = from type in entities.GroupBy(x => x.Type)
                                  select new
                                  {
                                      type.First().Type,
                                      Count = type.Count(),
                                  };
            return aspirationTypes;
        }

        async Task<Object> IDashBoardService.GetApprovalAsync(FilterCondition filterCondition)
        {
            var entities = await _repository.FindAllAsync();
            var approval = from buApproval in entities.GroupBy(x => x.BUApproved == true ? "Approved" : "Rejected")
                           select new
                           {
                               buApproval.First().BUApproved,
                               Count = buApproval.Count(),

                           };
            return approval;

        }

        async Task<Object> IDashBoardService.GetFullfilmentAsync()
        {
            var entities = await _repository.FindAllAsync();
            var fullfillment = from fullfill in entities.Where(ful => ful.BUApproved == true && ful.FullFillBy.HasValue).GroupBy(ffill => new { Convert.ToDateTime(ffill.FullFillBy.ToString()).Year, Convert.ToDateTime(ffill.FullFillBy.ToString()).Month})
                               select new
                               {
                                   Convert.ToDateTime(fullfill.First().FullFillBy.ToString()).Year,
                                   Convert.ToDateTime(fullfill.First().FullFillBy.ToString()).Month,
                                   Count = fullfill.Count(),
                               };

            return fullfillment;
        }
    }
}
