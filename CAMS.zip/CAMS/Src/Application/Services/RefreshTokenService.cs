﻿namespace Application.Services
{
    //public class RefreshTokenService : IRefreshTokenService
    //{
    //    public Task<EntityResponseModel> CreateAsync(IAuditableRequest model)
    //    {

    //    }

    //    public Task<bool> DeleteAsync(int id)
    //    {

    //    }

    //    public Task<EntityResponseModel> GetAllAsync(int pageNo = 1, int pageSize = 10)
    //    {
    //    }

    //    public Task<EntityResponseModel> GetByCategoryAsync(FilterModel[] filterModels, bool isReturnSingleValue = true, int pageNo = 1, int pageSize = 10, string sortFiled = "", int sortOrder = -1)
    //    {
    //    }

    //    public Task<EntityResponseModel> UpdateAsync(IAuditableRequest model)
    //    {
    //    }
    //}
}
