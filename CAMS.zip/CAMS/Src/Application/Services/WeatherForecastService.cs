﻿using Application.DTO.Auditable;
using Application.DTO.EntityResponse;
using Application.DTO.WeatherForecast;
using Application.Extensions;
using Application.Helpers;
using Application.Interfaces;
using AutoMapper;
using Common;
using Common.Enums;
using Core.Entities;
using Core.Entities.BaseEntity;
using Infrastructure.Context;
using Infrastructure.Repository.Interfaces;
using Infrastructure.Specifications.Interfaces;
using Infrastructure.UnitOfWork.Interfaces;
using System.Data;
using System.Linq.Expressions;

namespace Application.Services
{
    public class WeatherForecastService : IWeatherForecastService
    {
        //private readonly IUnitOfWork<DataContext> _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IRepository<WeatherForecast> _repository;
        int pageNo = 1;
        int pageSize = 10;
        public WeatherForecastService(IMapper mapper
            , IRepository<WeatherForecast> repository)
        {
            //_unitOfWork = unitOfWork;
            _mapper = mapper;
            _repository = repository;
        }

        private ISpecification<WeatherForecast> GetSpecification(Expression<Func<WeatherForecast, bool>> expression = null, string sortField = "none", int sortOrder = -1)
        {

            if (expression == null)
                expression = v => v.IsDeleted != true;
            Infrastructure.Specifications.BaseSpecification<WeatherForecast> specification =
                                                                new Infrastructure.Specifications.BaseSpecification<WeatherForecast>(expression);

            if (sortField != "none" && !string.IsNullOrEmpty(sortField))
                specification.OrderByDescending = p => p.GetSortOrder(sortField, sortOrder);
            else
                specification.OrderByDescending = p => p.OrderByDescending(p => p.IsActive)
                                                   .ThenByDescending(p => p.CreatedDate)
                                                   .ThenByDescending(p => p.Id);
            specification.IsPagingEnabled = true;
            specification.Skip = (pageNo - 1) * pageSize;
            specification.Take = pageSize;

            return specification;
        }


        public async Task<EntityResponseModel> UpdateAsync(List<IAuditableRequest> models)
        {
            List<WeatherForecast> entities = new List<WeatherForecast>();
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            foreach (var item in models)
            {
                if (item == null) continue;
                WeatherForecastRequest weatherForecastRequest = (WeatherForecastRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "name",
                            Type = FilterType.e.ToString(),
                            Value = weatherForecastRequest.name
                        }
                   };
                Expression<Func<WeatherForecast, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new WeatherForecast(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) == 1)
                {
                    var entity = _mapper.Map<WeatherForecast>(weatherForecastRequest);
                    await _repository.UpdateAsync(entity);
                    //await _unitOfWork.SaveAsync();

                    entities.Add(entity);
                }

            }
            entityResponseModel.Entity = entities;
            entityResponseModel.EntityResponse = _mapper.Map<List<WeatherForecastResponse>>(entities);
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }

        public async Task<EntityResponseModel> CreateAsync(List<IAuditableRequest> models)
        {
            EntityResponseModel entityResponses = new EntityResponseModel();
            List<WeatherForecast> entities = new List<WeatherForecast>();

            foreach (var item in models)
            {
                if (item == null) continue;
                WeatherForecastRequest weatherForecastRequest = (WeatherForecastRequest)item;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "name",
                            Type = FilterType.e.ToString(),
                            Value = weatherForecastRequest.name
                        }
                   };
                Expression<Func<WeatherForecast, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new WeatherForecast(), filterConditions);
                if (await _repository.CountAsync(GetSpecification(expression)) < 1)
                {
                    var entity = _mapper.Map<WeatherForecast>(weatherForecastRequest);
                    await _repository.AddAsync(entity);
                    entities.Add(entity);
                }

            }
            entityResponses.EntityResponse = _mapper.Map<List<WeatherForecastResponse>>(entities);
            entityResponses.Entity = entities;
            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponses.EntityResponse, string.Empty),
                Entity = entityResponses.Entity,
                EntityResponse = entityResponses.EntityResponse
            };
        }

        public async Task<bool> DeleteAsync(List<int> ids)
        {
            List<AuditableEntity> entities = new List<AuditableEntity>();

            foreach (var item in ids)
            {
                if (item == null) continue;

                FilterModel[] filterConditions = new FilterModel[]
                   {
                        new FilterModel
                        {
                            Combination = FilterCombination.And,
                            Key= "id",
                            Type = FilterType.e.ToString(),
                            Value = item.ToString()
                        }
                   };
                Expression<Func<WeatherForecast, bool>> expression = v => v.IsDeleted != true;
                expression = expression.GetExpressionFromProperties(new WeatherForecast(), filterConditions);
                var entity = await _repository.FindAsync(GetSpecification(expression));
                var entityVal = entity.FirstOrDefault();
                if (entityVal != null)
                {
                    await _repository.RemoveAsync(entityVal);
                }
            }
            return true;

        }

        public async Task<EntityResponseModel> GetAsync(FilterCondition filterCondition)
        {
            Expression<Func<WeatherForecast, bool>> expression = v => v.IsDeleted != true;
            EntityResponseModel entityResponseModel = new EntityResponseModel();
            if (filterCondition != null && filterCondition.FilterModels.Any())
                expression = expression.GetExpressionFromProperties(new WeatherForecast(), filterCondition);
            var entities = await _repository.FindAsync(GetSpecification(expression));
            entityResponseModel.EntityResponse = _mapper.Map<List<WeatherForecastResponse>>(entities);

            return new EntityResponseModel
            {
                APIResponse = APIResponseHelper.Getinstance().ConvertToAPIResponse(entityResponseModel.EntityResponse, string.Empty),
                Entity = entityResponseModel.Entity,
                EntityResponse = entityResponseModel.EntityResponse
            };
        }
    }
}
