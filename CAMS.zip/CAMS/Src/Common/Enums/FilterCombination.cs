﻿namespace Common.Enums
{
    public enum FilterCombination
    {
        And = 1,
        Or = 2,
    }
}
