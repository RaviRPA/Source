﻿namespace Common.Enums
{
    public enum FilterType
    {
        e = 1,
        c = 2,
        sw = 3,
        ew = 4,
        gt = 5,
        lt = 6,
        ge = 7,
        le = 8,
        ne = 9
    }
}
