﻿using Common.Enums;

namespace Common
{
    public class FilterModel
    {
        public string? Key { get; set; }
        public string? Value { get; set; }
        public string Type { get; set; }
        public FilterCombination Combination { get; set; }
    }
    public class FilterCondition
    {
        public List<FilterModel[]> FilterModels { get; set; }

        public FilterCombination[] Combination { get; set; }

        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public string SortField { get; set; }
        public int SortOrder { get; set; }
    }
}
