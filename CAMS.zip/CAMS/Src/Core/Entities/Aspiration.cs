﻿using Core.Entities.BaseEntity;
using System.ComponentModel.DataAnnotations;


namespace Core.Entities
{
    public class Aspiration : AuditableEntity
    {
        
        [Required]
        [StringLength(50)]
        [MinLength(2)]
        public string Title { get; set; }



        [StringLength(100)]
        [MinLength(2)]
        public string Description { get; set; }



        [Required]
        [StringLength(20)]
        public string Type { get; set; }



        [Required]
        [StringLength(50)]
        [MinLength(2)]
        public string Status { get; set; }
        public bool? RMSApproved { get; set; }
        public bool? BUApproved { get; set; }
        public DateTime? FullFillBy { get; set; }
    }
}
