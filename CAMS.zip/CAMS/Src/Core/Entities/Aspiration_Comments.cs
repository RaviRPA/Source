﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Core.Entities.BaseEntity;

namespace Core.Entities
{
    public class Aspiration_Comments : AuditableEntity
    {
        public virtual int AspirationId { get; set; }
        [ForeignKey("AspirationId")]
        public virtual Aspiration Aspiration { get; set; }
        [Required]
        [StringLength(500)]
        [MinLength(2)]
        public string Comments { get; set; }


    }
}
