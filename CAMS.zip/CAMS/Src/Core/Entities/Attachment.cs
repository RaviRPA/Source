﻿using Core.Entities.BaseEntity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Entities
{
    public class Attachment: AuditableEntity
    {
        
        public virtual int AspirationId { get; set; }
        [ForeignKey("AspirationId")]
        public virtual Aspiration Aspiration { get; set; }
        public string FilePath { get; set; }
    }
}
