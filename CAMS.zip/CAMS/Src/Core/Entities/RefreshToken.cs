﻿using Core.Entities.BaseEntity;

namespace Core.Entities
{
    public class RefreshToken : AuditableEntity
    {
        public string Token { get; set; }
        public DateTime Expires { get; set; }
        public DateTime? Revoked { get; set; }
        public string RevokedBy { get; set; }
        public string ReplacedByToken { get; set; }
        public string ReasonRevoked { get; set; }
        public bool IsExpired => DateTime.Now >= Expires;
        public bool IsRevoked => Revoked != null;
        public int? EmployeeId { get; set; }



        #region Navigation Properties
        #endregion

    }
}
