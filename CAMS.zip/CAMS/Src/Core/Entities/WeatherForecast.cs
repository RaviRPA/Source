using Core.Entities.BaseEntity;

namespace Core.Entities
{
    public class WeatherForecast : AuditableEntity
    {

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string? Summary { get; set; }
        public string Name { get; set; }
    }
}