﻿using Core.Entities;
using Core.Entities.BaseEntity;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Context
{
    public  class DataContext : DbContext
    {
        public DataContext()
        {
        }

        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }
        public Guid CurrentUserId { get; set; }

        public virtual DbSet<WeatherForecast> WeatherForecast { get; set; }
        public virtual DbSet<Aspiration> tbl_Aspirations { get; set; }
        public virtual DbSet<Aspiration_Comments> tbl_Aspiration_Comments { get; set; }
        public virtual DbSet<Attachment> tbl_Attachments { get; set; }

        //public virtual DbSet<RefreshToken> WeatherForecast { get; set; }


        //private readonly IConfiguration Configuration;
        //public DataContext(IConfiguration configuration)
        //{
        //    Configuration = configuration;
        //}
        //protected override void OnConfiguring(DbContextOptionsBuilder options)
        //{
        //    options.UseSqlServer(Configuration.GetConnectionString("League_10.DeviceRegistrationAPI"));
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                //optionsBuilder.UseSqlServer("Server=WEMVBABDBD001\\VBABDBD001;initial Catalog=QSATAPI;integrated security=True");
            }
        }

        public bool SeedData()
        {
            SaveChangesAsync();
            return true;
        }

        private void UpdateAuditEntitiesProperties()
        {
            var modifiedEntries = ChangeTracker.Entries()
                .Where(x => x.Entity is AuditableEntity && (x.State == EntityState.Added || x.State == EntityState.Modified));


            foreach (var entry in modifiedEntries)
            {
                var entity = (AuditableEntity)entry.Entity;
                DateTime now = DateTime.Now;

                if (entry.State == EntityState.Added)
                {
                    entity.CreatedDate = now;
                    entity.UpdatedDate = now;
                    entity.CreatedBy = CurrentUserId;
                    entity.UpdatedBy = CurrentUserId;

                }
                else
                {
                    base.Entry(entity).Property(x => x.CreatedBy).IsModified = false;
                    base.Entry(entity).Property(x => x.CreatedDate).IsModified = false;
                    entity.UpdatedDate = now;
                    entity.UpdatedBy = CurrentUserId;
                }

            }
        }
        public override int SaveChanges()
        {
            UpdateAuditEntitiesProperties();
            return base.SaveChanges();
        }

        public async override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            UpdateAuditEntitiesProperties();
            var returnVal = await base.SaveChangesAsync();
            ChangeTracker.Clear();
            return returnVal;
        }

    }
}
