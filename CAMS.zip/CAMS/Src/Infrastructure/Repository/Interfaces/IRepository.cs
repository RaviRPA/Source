﻿using Infrastructure.Context;
using Infrastructure.Specifications.Interfaces;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Linq.Expressions;

namespace Infrastructure.Repository.Interfaces
{
    public interface IRepository<TEntity> where TEntity : class
    {
        DataContext Context { get; set; }
        Task<IEnumerable<TEntity>> FindAllAsync();
        Task<TEntity> FindByIdAsync(int id);
        Task<TEntity> FindByNameAsync(string name);
        Task UpdateAsync(TEntity entity);
        Task<TEntity> AddAsync(TEntity entity);
        Task AddRangeAsync(IEnumerable<TEntity> entities);
        Task RemoveAsync(TEntity entity);
        Task RemoveRangeAsync(IEnumerable<TEntity> entities);
        Task<IEnumerable<TEntity>> FindAsync(ISpecification<TEntity> specification = null);

        // To include related entity (foreign key table info.)
        //Task<IEnumerable<TEntity>> FindAsync(ISpecification<TEntity> specification = null, string referencedEntity = null);
        //to include Entites
        Task<IEnumerable<TEntity>> FindAsync(string[] referencedEntities, ISpecification<TEntity> specification = null);

        Task<bool> ContainsAsync(ISpecification<TEntity> specification = null);
        Task<bool> ContainsAsync(Expression<Func<TEntity, bool>> predicate);
        Task<int> CountAsync(ISpecification<TEntity> specification = null);
        Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate);
        IRepository<T> GenericRepository<T>() where T : class;
        
    }
}