﻿using Core;
using Infrastructure.Context;
using Infrastructure.Repository.Interfaces;
using Infrastructure.Specifications;
using Infrastructure.Specifications.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using EntityState = Microsoft.EntityFrameworkCore.EntityState;


namespace Infrastructure.Repository
{
    public class Repository<TEntity> : IRepository<TEntity>, IDisposable where TEntity : class
    {

        private DbSet<TEntity> _entities;
        private string _errorMessage = string.Empty;
        private bool _isDisposed;
        private Dictionary<string, object> repository;

        //public Repository(IUnitOfWork<DataContext> unitOfWork)
        //    : this(unitOfWork.Context)
        //{
        //}
        public Repository(DataContext context)
        {
            _isDisposed = false;
            Context = context;
        }
        public DataContext Context { get; set; }

        public virtual IQueryable<TEntity> Table
        {
            get { return Entities; }
        }
        protected virtual DbSet<TEntity> Entities
        {
            get { return _entities ?? (_entities = (DbSet<TEntity>?)Context.Set<TEntity>()); }
        }
        public void Dispose()
        {
            if (Context != null)
                Context.Dispose();
            _isDisposed = true;
        }

        public async Task<IEnumerable<TEntity>> FindAllAsync()
        {

            return await Entities.ToListAsync();
        }
        public async Task<TEntity> FindByIdAsync(int id)
        {

            return await Entities.FindAsync(id);
        }

        public async Task<TEntity> FindByNameAsync(string name)
        {

            return await Entities.FindAsync(name);
        }

        public async Task<TEntity> AddAsync(TEntity entity)
        {
            try
            {
                if (entity == null)

                    throw new ArgumentNullException("entity");

                 await Entities.AddAsync(entity);
               await Context.SaveChangesAsync();
                return entity;
                if (Context == null || _isDisposed)
                    Context = new DataContext();

            }
            catch (Exception dbEx)
            {
                throw new AppException(dbEx.Message, dbEx);
            }

        }


        public async Task AddRangeAsync(IEnumerable<TEntity> entities)
        {
            try
            {
                if (entities == null)

                    throw new ArgumentNullException("entity");

                await Entities.AddRangeAsync(entities);
                await Context.SaveChangesAsync();
                if (Context == null || _isDisposed)
                    Context = new DataContext();

            }
            catch (Exception dbEx)
            {
                throw new AppException(dbEx.Message, dbEx);
            }

        }
        public async Task UpdateAsync(TEntity entity)
        {
            try
            {
                if (entity == null)
                    throw new ArgumentNullException("entity");
                if (Context == null || _isDisposed)
                    Context = new DataContext();
                SetEntryModified(entity);
                await Context.SaveChangesAsync();
            }
            catch (Exception dbEx)
            {
                throw new AppException(dbEx.Message, dbEx);
            }

        }
        public virtual void SetEntryModified(TEntity entity)
        {
            Context.Entry(entity).State = EntityState.Modified;
        }

        public async Task RemoveAsync(TEntity entity)
        {
            try
            {
                if (entity == null)
                    throw new ArgumentNullException("entity");
                if (Context == null || _isDisposed)
                    Context = new DataContext();
                Entities.Remove(entity);
                await Context.SaveChangesAsync();
            }
            catch (Exception dbEx)
            {
                throw new AppException(dbEx.Message, dbEx);
            }

        }


        public async Task RemoveRangeAsync(IEnumerable<TEntity> entities)
        {
            try
            {
                if (entities == null)
                    throw new ArgumentNullException("entity");
                if (Context == null || _isDisposed)
                    Context = new DataContext();
                Entities.RemoveRange(entities);

            }
            catch (Exception dbEx)
            {
                throw new AppException(dbEx.Message, dbEx);
            }

        }
        public async Task<IEnumerable<TEntity>> FindAsync(ISpecification<TEntity> specification = null)
        {
            return ApplySpecification(specification);
        }

        // To include related entity (foreign key table info.)
        //public async Task<IEnumerable<TEntity>> FindAsync(ISpecification<TEntity> specification = null, string referencedEntity = null)
        //{
        //    return ApplySpecification(specification, referencedEntity);
        //}
        public async Task<bool> ContainsAsync(ISpecification<TEntity> specification = null)
        {
            return await CountAsync(specification) > 0 ? true : false;
        }

        public async Task<bool> ContainsAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await CountAsync(predicate) > 0 ? true : false;
        }

        public async Task<int> CountAsync(ISpecification<TEntity> specification = null)
        {
            return ApplySpecification(specification).Count();
        }

        public async Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).Count();
        }
        private IQueryable<TEntity> ApplySpecification(ISpecification<TEntity> spec)
        {
            return SpecificationEvaluator<TEntity>.GetQuery(Entities.AsQueryable(), spec);
        }

        // To include related entity (foreign key table info.)
        //private IQueryable<TEntity> ApplySpecification(ISpecification<TEntity> spec, string referencedEntity)
        //{
        //    return SpecificationEvaluator<TEntity>.GetQuery(Entities.AsQueryable().Include(referencedEntity), spec);
        //}

        public async Task<IEnumerable<TEntity>> FindAsync(string[] referencedEntities, ISpecification<TEntity> specification =null)
        {
            return ApplySpecification(specification, referencedEntities);
        }

        private IQueryable<TEntity> ApplySpecification(ISpecification<TEntity> spec, string[] referencedEntities)
        {
            IQueryable<TEntity> result;
            result = SpecificationEvaluator<TEntity>.GetQuery(Entities.AsQueryable(), spec);
            foreach(string refEntity in referencedEntities)
            {
                result = result.Include(refEntity);
            }

            return result;
        }

        public IRepository<T> GenericRepository<T>() where T : class
        {
            if (repository == null)
                repository = new Dictionary<string, object>();
            var type = typeof(T).Name;
            if (!repository.ContainsKey(type))
            {
                var repositoryType = typeof(Repository<T>);
                var repositoryInstance = Activator.CreateInstance(repositoryType, Context);
                repository.Add(type, repositoryInstance);
            }
            return (Repository<T>)repository[type];
        }

    }
}
