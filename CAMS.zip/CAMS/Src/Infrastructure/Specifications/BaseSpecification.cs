﻿using Infrastructure.Specifications.Interfaces;
using System.Linq.Expressions;

namespace Infrastructure.Specifications
{
    public class BaseSpecification<T> : ISpecification<T>
    {
        public BaseSpecification(Expression<Func<T, bool>> criteria)
        {
            Criteria = criteria;
        }
        protected BaseSpecification()
        {

        }
        public Expression<Func<T, bool>> Criteria { get; }
        //  public List<Expression<Func<T, object>>> Includes { get;  } = new List<Expression<Func<T, object>>>();
        public Func<IQueryable<T>, IQueryable<T>> IncludeExp { get; set; } //= new List<Expression<Func<T, object>>>();


        public List<string> IncludeStrings { get; } = new List<string>();
        public Expression<Func<T, object>> OrderBy { get; set; }
        public Func<IQueryable<T>, IQueryable<T>> OrderByDescending { get; set; }
        public Expression<Func<T, object>> GroupBy { get; set; }
        public Expression<Func<T, object>> ThenBy { get; set; }

        public int Take { get; set; }
        public int Skip { get; set; }
        public bool IsPagingEnabled { get; set; }

        //public virtual void AddInclude(Expression<Func<T, object>> includeExpression)
        //{
        //    Include.Add(includeExpression);
        //}

        protected virtual void AddInclude(string includeString)
        {
            IncludeStrings.Add(includeString);
        }

        protected virtual void ApplyPaging(int skip, int take)
        {
            Skip = skip;
            Take = take;
            IsPagingEnabled = true;
        }

        protected virtual void ApplyOrderBy(Expression<Func<T, object>> orderByExpression)
        {
            OrderBy = orderByExpression;
        }

        //protected virtual void ApplyOrderByDescending(Expression<Func<T, object>> orderByDescendingExpression)
        //{
        //    OrderByDescending = orderByDescendingExpression;
        //}

        protected virtual void ApplyGroupBy(Expression<Func<T, object>> groupByExpression)
        {
            GroupBy = groupByExpression;
        }
        protected virtual void ApplyThenBy(Expression<Func<T, object>> thenByExpression)
        {
            ThenBy = thenByExpression;
        }
    }
}
