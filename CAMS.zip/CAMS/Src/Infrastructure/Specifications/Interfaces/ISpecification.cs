﻿using System.Linq.Expressions;

namespace Infrastructure.Specifications.Interfaces
{
    public interface ISpecification<T>
    {
        Expression<Func<T, bool>> Criteria { get; }
        Func<IQueryable<T>, IQueryable<T>> IncludeExp { get; set; }

        List<string> IncludeStrings { get; }
        Expression<Func<T, object>> OrderBy { get; }
        Func<IQueryable<T>, IQueryable<T>> OrderByDescending { get; set; }

        //  Expression<Func<T, object>> OrderByDescending { get; set; }
        Expression<Func<T, object>> GroupBy { get; }
        Expression<Func<T, object>> ThenBy { get; set; }
        int Take { get; }
        int Skip { get; }
        bool IsPagingEnabled { get; }
    }
}
