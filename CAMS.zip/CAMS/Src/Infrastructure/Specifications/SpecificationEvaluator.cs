﻿using Infrastructure.Specifications.Interfaces;

namespace Infrastructure.Specifications
{
    public class SpecificationEvaluator<TEntity> where TEntity : class
    {
        public static IQueryable<TEntity> GetQuery(IQueryable<TEntity> query, ISpecification<TEntity> specification)
        {
            IOrderedQueryable<TEntity> temp = null;

            if (specification.Criteria != null)
            {
                query = query.Where(specification.Criteria);
            }

            if (specification.IncludeExp != null)

                query = specification.IncludeExp(query);


            if (specification.OrderBy != null)
            {
                temp = query.OrderBy(specification.OrderBy);
                query = temp;
            }
            else if (specification.OrderByDescending != null)
            {
                query = specification.OrderByDescending(query);
                // temp = query.(specification.OrderByDescending);
                // query = temp;
            }

            if (specification.GroupBy != null)
            {
                query = query.GroupBy(specification.GroupBy).SelectMany(x => x);
            }
            if (specification.ThenBy != null)
            {
                query = temp.ThenBy(specification.ThenBy);
            }


            if (specification.IsPagingEnabled)
            {
                query = query.Skip(specification.Skip)
                             .Take(specification.Take);
            }
            return query;
        }
    }
}
