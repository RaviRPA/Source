﻿using Infrastructure.Context;
using Infrastructure.Repository.Interfaces;

namespace Infrastructure.UnitOfWork
{
    public interface IUnitOfWork<out TContext>
        where TContext : DataContext, new()
    {
        TContext Context { get; }
        //void CreateTransaction();
        //void Commit();
        //void Rollback();
        Task<int> SaveAsync();
        IRepository<T> GenericRepository<T>() where T : class;
    }
}
