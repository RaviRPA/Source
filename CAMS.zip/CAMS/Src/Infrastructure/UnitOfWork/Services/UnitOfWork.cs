﻿using Infrastructure.Context;
using Infrastructure.Repository;
using Infrastructure.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.UnitOfWork.Services
{
    public class UnitOfWork<TContext> : IUnitOfWork<TContext>, IDisposable
         where TContext : DataContext, new()
    {
        private readonly TContext _context;
        private bool _disposed;
        private string _errorMessage = string.Empty;
        //private IDbContextTransaction _objTran;
        private Dictionary<string, object> _repositories;


        public UnitOfWork(TContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        public TContext Context
        {
            get { return _context; }
        }
        //public void CreateTransaction()
        //{
        //    _objTran = _context.Database.BeginTransaction();
        //}
        //public void Commit()
        //{
        //    _objTran.Commit();
        //}
        //public void Rollback()
        //{
        //    _objTran.Rollback();
        //    _objTran.Dispose();
        //}

        public async Task<int> SaveAsync()
        {
            int returnVal = -1;
            try
            {
                returnVal = await _context.SaveChangesAsync();
            }
            catch (DbUpdateException dbEx)
            {
                //foreach (var validationErrors in dbEx.InnerException)
                //    foreach (var validationError in validationErrors.ValidationErrors)
                //        _errorMessage += string.Format("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                //throw new AppException(_errorMessage, dbEx);
            }
            return returnVal;
        }
        public IRepository<T> GenericRepository<T>() where T : class
        {
            if (_repositories == null)
                _repositories = new Dictionary<string, object>();
            var type = typeof(T).Name;
            if (!_repositories.ContainsKey(type))
            {
                var repositoryType = typeof(Repository<T>);
                var repositoryInstance = Activator.CreateInstance(repositoryType, _context);
                _repositories.Add(type, repositoryInstance);
            }
            return (Repository<T>)_repositories[type];
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
                if (disposing)
                    _context.Dispose();
            _disposed = true;
        }

    }
}
