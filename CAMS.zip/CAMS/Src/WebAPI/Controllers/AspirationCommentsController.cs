﻿using Application.DTO.Auditable;
using Application.DTO.Aspiration_Comments;
using Application.Interfaces;
using Common;
using Microsoft.AspNetCore.Mvc;
using Application.Services;


namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AspirationCommentsController : ControllerBase
    {
        private readonly IAspirationCommentsService _aspirationCommentsService;
        static readonly string[] scopeRequiredByApi = new string[] { "ReadWriteAccess" };

        public AspirationCommentsController(IAspirationCommentsService aspirationCommentsService)
        {
            _aspirationCommentsService = aspirationCommentsService;
        }

        [HttpGet("Gett")]
        public async Task<IActionResult> GetAsyncc()
        {
            var filterConditions = new FilterCondition();
            filterConditions = null;
            var response = await _aspirationCommentsService.GetAsync(filterConditions);
            return Ok(response.EntityResponse);
        }

        [HttpPost("Get")]
        public async Task<IActionResult> GetAsync([FromBody] FilterCondition? filterConditions = null)
        {
            var response = await _aspirationCommentsService.GetAsync(filterConditions);
            return Ok(response.APIResponse);
        }


        [HttpPost("Create")]
        public async Task<IActionResult> CreateAsync(List<AspirationCommentsRequest> aspirationCommentsRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in aspirationCommentsRequests)
            {
                requests.Add(item);
            }
            var response = await _aspirationCommentsService.CreateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateAsync(List<AspirationCommentsRequest> aspirationCommentsRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in aspirationCommentsRequests)
                requests.Add(item);
            {
            }
            var response = await _aspirationCommentsService.UpdateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteAsync(List<int> ids)
        {
            return Ok(await _aspirationCommentsService.DeleteAsync(ids));
        }
    }
}
