﻿using Application.DTO.Auditable;
using Application.DTO.Aspiration;
using Application.Interfaces;
using Common;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    //[Authorize]
    [ApiController]
    public class AspirationController : ControllerBase
    {
        private readonly IAspirationService _aspirationService;
        static readonly string[] scopeRequiredByApi = new string[] { "ReadWriteAccess" };

        public AspirationController(IAspirationService aspirationService)
        {
            _aspirationService = aspirationService;
        }

         [HttpGet("Gett")]
        public async Task<IActionResult> GetAsyncc()
        {
            var filterConditions = new FilterCondition();
            filterConditions = null;
            var response = await _aspirationService.GetAsync(filterConditions);
            return Ok(response.EntityResponse);
        }

        [HttpPost("Get")]
        public async Task<IActionResult> GetAsync([FromBody] FilterCondition? filterConditions = null)
        { 
            var response = await _aspirationService.GetAsync(filterConditions);
            return Ok(response.APIResponse);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateAsync(List<AspirationRequest> aspirationRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in aspirationRequests)
            {
                requests.Add(item);
            }
            var response = await _aspirationService.CreateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateAsync(List<AspirationRequest> aspirationRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in aspirationRequests)
            {
                requests.Add(item);
            }
            var response = await _aspirationService.UpdateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteAsync(List<int> ids)
        {
            return Ok(await _aspirationService.DeleteAsync(ids));
        }
    }
}
