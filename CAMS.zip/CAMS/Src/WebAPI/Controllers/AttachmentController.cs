﻿using Application.DTO.Attachment;
using Application.DTO.Auditable;
using Application.Interfaces;
using Application.Services;
using Common;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttachmentController : ControllerBase
    {
        private readonly IAttachmentService _IAttachmentService;
        static readonly string[] scopeRequiredByApi = new string[] { "ReadWriteAccess" };

        public AttachmentController(IAttachmentService IAttachmentService)
        {
            _IAttachmentService = IAttachmentService;
        }

        [HttpGet("Gett")]
        public async Task<IActionResult> GetAsyncc()
        {
            var filterConditions = new FilterCondition();
            filterConditions = null;
            var response = await _IAttachmentService.GetAsync(filterConditions);
            return Ok(response.EntityResponse);
        }

        [HttpPost("Get")]
        public async Task<IActionResult> GetAsync([FromBody] FilterCondition? filterConditions = null)
        {
            var response = await _IAttachmentService.GetAsync(filterConditions);
            return Ok(response.APIResponse);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateAsync(List<AttachmentRequest> attachmentRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in attachmentRequests)
            {
                requests.Add(item);
            }
            var response = await _IAttachmentService.CreateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateAsync(List<AttachmentRequest> attachmentRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in attachmentRequests)
            {
                requests.Add(item);
            }
            var response = await _IAttachmentService.UpdateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteAsync(List<int> ids)
        {
            return Ok(await _IAttachmentService.DeleteAsync(ids));
        }

    }
}