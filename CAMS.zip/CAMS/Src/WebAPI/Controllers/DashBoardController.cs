﻿using Application.Interfaces;
using Application.Services;
using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashBoardController : ControllerBase
    {
        private readonly IDashBoardService _dashboardService;
        
        public DashBoardController(IDashBoardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        [HttpGet("Get")]
        public async Task<IActionResult> GetAsync()
        {
            var filterConditions = new FilterCondition();
            filterConditions = null;
            var response = await _dashboardService.GetTypeWiseAspirationAsync(filterConditions);
            return Ok(response.ToJson());
        }

        [HttpPost("Gett")]
        public async Task<IActionResult> GetAsync([FromBody] FilterCondition? filterConditions = null)
        {
            var response = await _dashboardService.GetApprovalAsync(filterConditions);
            return Ok(response.ToJson());
        }

        [HttpGet("Gett")]
        public async Task<IActionResult> GetFullfilmentAsync()
        {
            var response = await _dashboardService.GetFullfilmentAsync();
            return Ok(response.ToJson());
        }

    }
}
