﻿using Application.DTO.Auditable;
using Application.DTO.WeatherForecast;
using Application.Interfaces;
using Azure.Core;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [ApiController]
    //[Authorize]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IWeatherForecastService _weatherForecastService;
        static readonly string[] scopeRequiredByApi = new string[] { "ReadWriteAccess" };

        public WeatherForecastController(IWeatherForecastService weatherForecastService)
        {
            _weatherForecastService = weatherForecastService;
        }

        [HttpGet("Gett")]
        public async Task<IActionResult> GetAsyncc()
        {
            var filterConditions = new FilterCondition();
            filterConditions = null;
            var response = await _weatherForecastService.GetAsync(filterConditions);
            return Ok(response.EntityResponse);
        }


        [HttpPost("Get")]
        public async Task<IActionResult> GetAsync([FromBody] FilterCondition? filterConditions = null)
        {
            var response = await _weatherForecastService.GetAsync(filterConditions);
            return Ok(response.APIResponse);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateAsync(List<WeatherForecastRequest> weatherForecastRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in weatherForecastRequests)
            {
                requests.Add(item);
            }
            var response = await _weatherForecastService.CreateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateAsync(List<WeatherForecastRequest> weatherForecastRequests)
        {
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in weatherForecastRequests)
            {
                requests.Add(item);
            }
            var response = await _weatherForecastService.UpdateAsync(requests);
            return Ok(response.APIResponse);
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteAsync(List<int> ids)
        {
            return Ok(await _weatherForecastService.DeleteAsync(ids));
        }

    }
}
