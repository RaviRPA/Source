using Application.Interfaces;
using Application.Services;
using Infrastructure.Context;
using Infrastructure.Repository;
using Infrastructure.Repository.Interfaces;
using Infrastructure.Specifications;
using Infrastructure.Specifications.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Microsoft.OpenApi.Models;
using System.Text.Json.Serialization;
using WebAPI.Middlewares;

var builder = WebApplication.CreateBuilder(args);

var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

#region Add services to the container.
// Adds Microsoft Identity platform (Azure AD B2C) support to protect this Api
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddMicrosoftIdentityWebApi(options =>
        {
            builder.Configuration.Bind("AzureAdB2C", options);

            options.TokenValidationParameters.NameClaimType = "name";
        },
options => { 
    builder.Configuration.Bind("AzureAdB2C", options);
});
// End of the Microsoft Identity platform block 

//builder.Services.AddCors(options =>
//{
//    options.AddPolicy(name: MyAllowSpecificOrigins,
//        policy =>
//        {
//            policy.WithOrigins("https://localhost:4200")
//            .AllowAnyHeader()
//            .AllowAnyMethod();
//        });
//});



builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddControllers().AddJsonOptions(
               x =>
               {
                   x.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                   x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                   x.JsonSerializerOptions.MaxDepth = 0;
               });
builder.Services.AddDbContext<DataContext>(options =>
{
    options.UseSqlServer(builder.Configuration["ConnectionStrings:deviceDetails"].ToString());
    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
});
DataContext dataContext = builder.Services.BuildServiceProvider().GetService<DataContext>();
dataContext.Database.Migrate();
dataContext.SeedData();

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
//builder.Services.AddSwaggerGen(c =>
//{
//builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//           .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAdB2C"));

builder.Services.AddControllers();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AzureAD_OAuth_API", Version = "v1" });
    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.OAuth2,
        Flows = new OpenApiOAuthFlows()
        {
            Implicit = new OpenApiOAuthFlow()
            {
                AuthorizationUrl = new Uri("https://login.microsoftonline.com/0a999a99-ac4f-9999-bb6e-4e99999f4d13/oauth2/v2.0/authorize"),
                TokenUrl = new Uri("https://login.microsoftonline.com/0a999a99-ac4f-9999-bb6e-4e99999f4d13/oauth2/v2.0/token"),
                Scopes = new Dictionary<string, string>
                            {
                                { "api://Z12e5ZZ8-cfc7-99d9-b094-999c81d70ce4/ReadAccess", "Reads the Weather forecast" },
                                { "api://Z12e5ZZ8-cfc7-99d9-b094-999c81d70ce4/ReadWriteAccess", "Reads and Writes the Weather forecast" }

                            }
            }
        }
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                     {
                     new OpenApiSecurityScheme
                        {
                        Reference = new OpenApiReference
                        {
                        Type = ReferenceType.SecurityScheme,
                        Id = "oauth2"
                        },
                                Scheme = "oauth2",
                                Name = "oauth2",
                                In = ParameterLocation.Header
                     },
                        new List<string>()
                     }
                });
});

builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
//builder.Services.AddScoped(typeof(IUnitOfWork<>), typeof(UnitOfWork<>));
builder.Services.AddScoped(typeof(ISpecification<>), typeof(BaseSpecification<>));
//builder.Services.AddScoped(IDbTransaction, DbContextTransaction);
builder.Services.AddScoped<IWeatherForecastService, WeatherForecastService>();
builder.Services.AddScoped<IAspirationService, AspirationService>();
builder.Services.AddScoped<IAspirationCommentsService, AspirationCommentsService>();
builder.Services.AddScoped<IAttachmentService, AttachmentService>();
builder.Services.AddScoped<IDashBoardService, DashBoardService>();

#endregion
var app = builder.Build();


// Configure the HTTP request pipeline.

//if (app.Environment.IsDevelopment())
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "CAMS_API v1");
        //c.RoutePrefix = string.Empty;
        c.OAuthClientId("Z99e5eb8-cfc7-99d9-b999-897c81d99ce4");
        c.OAuthClientSecret("9lZ9Z~INoHHuVHmVH2GqfKaxniL~loBia6R_yaZZ");
        c.OAuthUseBasicAuthenticationWithAccessCodeGrant();
    });
app.UseHttpsRedirection();
app.UseRouting();
var corurl = app.Configuration["CorsUrl"].ToString();
string[] origins = app.Configuration["CorsUrl"].Split(';');
app.UseCors(x => x
.SetIsOriginAllowed(origin => true)
.WithOrigins(origins)
.AllowAnyMethod()
.AllowAnyHeader()
.WithExposedHeaders("Content-Disposition")
.AllowCredentials());
app.UseOptions();
//app.UseCors(MyAllowSpecificOrigins);
// Add the following line 
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
