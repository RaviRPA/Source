﻿using WebAPI.Controllers;
using FakeItEasy;
using Application.Interfaces;
using Common;
using Microsoft.AspNetCore.Mvc;
using Application.DTO.Aspiration;
using System.Collections.Generic;
using Infrastructure.Repository.Interfaces;
using Core.Entities;
using Moq;
using AutoMapper;
using Application.Services;
using Application.DTO.Auditable;
using System;
using NUnit.Framework;


namespace UnitTests.Controllers
{

    [TestClass]
    public class AspirationControllerTests
    {
        private readonly IAspirationService _aspirationService;
        private readonly IMapper _mapper;
        private readonly IRepository<Aspiration> _repository;
        private readonly FilterCondition _filter;
        private readonly AspirationController _aspirationController;

        public AspirationControllerTests()
        {
            Mock<IRepository<Aspiration>> _repository = new Mock<IRepository<Aspiration>>();
            Mock<IMapper> _mapper = new Mock<IMapper>();
            Mock<FilterCondition> _filter = new Mock<FilterCondition>();
            //Mock<AspirationService> _aspirationService = new Mock<AspirationService>(); // (_mapper.Object, _repository.Object);
            _aspirationService = new AspirationService(_mapper.Object, _repository.Object);
            _aspirationController = new AspirationController(_aspirationService);
        }


        //[TestMethod]
        public void AspirationController_GetAsync_ReturnsTask()
        {
            // Arrange       

            // Act
            var result = _aspirationController.GetAsync(_filter);
            //object result = null;

            //var result = _aspirationService.GetAsync(_filter);

            // Assert
            NUnit.Framework.Assert.IsNotNull(result);
            //NUnit.Framework.Assert.IsInstanceOfType(result, typeof(Task<IActionResult>));
        }


        //[TestMethod]
        public void AspirationController_CreateAsync_ValidObjectPassed_ReturnTask()
        {
            // Arrange
            AspirationRequest aspirationsRequest = new AspirationRequest();
            aspirationsRequest.Title = "New Title";
            aspirationsRequest.Description = "New Description";
            aspirationsRequest.Type = "New Type";
            aspirationsRequest.Status = "Draft";

            List<AspirationRequest> aspirationsRequests = new List<AspirationRequest>();
            aspirationsRequests.Add(aspirationsRequest);

            // Act
            var result = _aspirationController.CreateAsync(aspirationsRequests);

            // Assert
            //Assert.IsNotNull(result);
            //NUnit.Framework.Assert.IsInstanceOfType(result, typeof(Task<IActionResult>));
        }


        //[TestMethod]
        public void AspirationService_CreateAsync_ValidObjectPassed_ReturnTask()
        {
            // Arrange
            AspirationRequest aspirationsRequest = new AspirationRequest();
            aspirationsRequest.Title = "New Title";
            aspirationsRequest.Description = "New Description";
            aspirationsRequest.Type = "New Type";
            aspirationsRequest.Status = "Draft";

            List<AspirationRequest> aspirationRequests = new List<AspirationRequest>();
            aspirationRequests.Add(aspirationsRequest);

            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            foreach (var item in aspirationRequests)
            {
                requests.Add(item);
            }

            // Act
            var result = _aspirationService.CreateAsync(requests);

            // Assert
            NUnit.Framework.Assert.IsNotNull(result);
            NUnit.Framework.Assert.AreEqual(result.Result.APIResponse.statusCode, 200);
            //Assert.IsInstanceOfType(result, typeof(Task<IActionResult>));
        }

        [TestMethod]
        public void AspirationService_CreateAsync_NullPassed_ReturnNullReferenceException()
        {
            // Arrange
            List<IAuditableRequest> requests = new List<IAuditableRequest>();
            requests = null;

            // Act
            TestDelegate action = () => _aspirationService.CreateAsync(requests);
            //System.Action action2 = () => _aspirationService.

            // Assert
            NUnit.Framework.Assert.Throws<System.NullReferenceException>(action);
        }


        //[TestMethod]
        public void AspirationController_DeleteAsync_ValidObjectPassed_ReturnTask_EntityResponseModel()
        {
            // Arrange
            List<int> aspirationsIds = new List<int>();
            aspirationsIds.Add(100);

            // Act
            var result = _aspirationController.DeleteAsync(aspirationsIds);

            // Assert
            NUnit.Framework.Assert.IsNotNull(result);
            //NUnit.Framework.Assert.IsInstanceOfType(result, typeof(Task<IActionResult>));
            //Assert.IsType<object>(result);  // typeof(OkObjectResult)
        }
    }
}
