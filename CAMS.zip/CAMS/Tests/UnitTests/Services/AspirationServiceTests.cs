﻿
namespace UnitTests.Services
{
    public class AspirationServiceTests
    {

    }

}
