﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

using NUnit.Framework;
using UnitTest;

// // Assembly level setup and teardown
[SetUpFixture]
class AssemblySeupTeardown
{
    [OneTimeSetUp]
    public void AssemblySetup()
    {

    }


    [OneTimeTearDown]
    public void AssemblyTeardown()
    {

    }
}

namespace SBI.Tests
{

    // Namespace level setup and teardown
    [SetUpFixture]
    class NamespaceSeupTeardown
    {
        [OneTimeSetUp]
        public void NamespaceSetup()
        {

        }


        [OneTimeTearDown]
        public void NamespaceTeardown()
        {

        }
    }

    [TestFixture]
    public class AccountTests
    {

        private Account _account;

        // Executed before each test
        [SetUp]
        public void Setup()
        {
            _account = new Account();
            // Reading from data file for test data
            // Connect to database and read test data
            // Connect to FTP and read data from remote file
        }

        // Executed after each test
        [TearDown]
        public void Teardown()
        {
            _account = null;
            // Close database connections
            // Close opened files
        }

        [Test]
        public void Withdraw_ValidAmount_ChangesBalance()
        {
            // arrange
            int currentBalance = 25000;
            int withdrawalAmount = 5000;
            int expectedBalance = 20000;            // Expected balance

            //Account account = new Account();
            //account.curBalance = currentBalance;    // Actual balance

            _account.curBalance = currentBalance;    // Actual balance

            // act
            //account.Withdraw(withdrawalAmount);
            _account.Withdraw(withdrawalAmount);

            // assert
            //Assert.That(account.curBalance, Is.EqualTo(expectedBalance));
            Assert.That(_account.curBalance, Is.EqualTo(expectedBalance));

            //// Older Versions
            //Assert.AreEqual(expectedBalance, account.curBalance);
        }


        [Test]
        [TestCase(50000, 25000, 25000)]
        [TestCase(25000, 25000, 0)]
        public void WithdrawTest_ValidAmount(int currentBalance, int withdrawalAmount, int expectedBalance)
        {

            Account account = new Account();
            account.curBalance = currentBalance;    // Actual balance

            // act
            account.Withdraw(withdrawalAmount);

            // assert
            Assert.That(account.curBalance, Is.EqualTo(expectedBalance));
        }


        [Test]
        public void DepositTest()
        {
            int currentBalance = 10000;
            int depositAmount = 5000;
            int expectedBalance = 15000;

            Account account = new Account();
            account.curBalance = currentBalance;

            // act
            account.Deposit(depositAmount);

            // assert
            Assert.AreEqual(expectedBalance, account.curBalance);

        }
    }
}
