﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest.Tests
{
    [TestClass()]
    public class TestClassTests
    {
        [TestMethod()]
        public void add2NumsTest()
        {
            // Arange


            // Act


            // Assert
            //Assert.Fail();
        }
    }
}