﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Account acc = new Account();
            acc.Deposit(25000);
            acc.Withdraw(5000);
            Console.WriteLine(acc.curBalance);

            Console.ReadLine();
        }
    }

    public class Account
    {
        public string accNumber;
        public int curBalance;
        public void Withdraw(int amount)
        {
            if (curBalance >= amount)
            {
                curBalance -= amount;
            }
            else
            {
                throw new ArgumentException(nameof(amount), "Withdrawal exceeds balance!");
            }
        }

        public void Deposit(int amount)
        {
            curBalance += amount;
        }
    }

    //public class TestClass
    //{
    //    public int add2Nums(int a, int b)
    //    {
    //        return a + b;
    //    }

    //}
}
