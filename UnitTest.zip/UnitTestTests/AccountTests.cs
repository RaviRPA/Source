﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using NUnit.Framework;
//using Assert = NUnit.Framework.Assert;

namespace UnitTest.Tests
{
    //[TestClass()]
    //[TestFixture]
    public class AccountTests
    {
        //[TestMethod]
        //[Timeout(2000)]  // Milliseconds
        public void Withdraw_ValidAmount_ChangesBalance()
        {
            // arrange
            int currentBalance = 25000;
            int withdrawalAmount = 5000;
            int expectedBalance = 20000;            // Expected balance

            Account account = new Account();
            account.curBalance = currentBalance;    // Actual balance

            // act
            account.Withdraw(withdrawalAmount);

            // assert
            //Assert.That(account.curBalance, Is.EqualTo(expectedBalance));

            //// Older Versions
            //Assert.AreEqual(expectedBalance, account.curBalance);

        }

        //[TestMethod()]
        //[Test]
        public void DepositTest()
        {
            int currentBalance = 10000;
            int depositAmount = 5000;
            int expectedBalance = 15000;

            Account account = new Account();
            account.curBalance = currentBalance;

            // act
            account.Deposit(depositAmount);

            // assert
            //Assert.AreEqual(expectedBalance, account.curBalance);

        }
    }
}